package com.sadee.optimizer

import android.app.ActivityManager
import android.content.Context
import android.os.BatteryManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { SadeeApp(this) }
    }
}

@Composable
private fun SadeeApp(context: Context) {
    var optimized by remember { mutableStateOf(false) }
    val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
    val mem = ActivityManager.MemoryInfo().also(am::getMemoryInfo)
    val usedRam = if (mem.totalMem > 0) ((mem.totalMem - mem.availMem) * 100 / mem.totalMem).toInt() else 0
    val bm = context.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
    val battery = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY).coerceIn(0, 100)

    MaterialTheme(colorScheme = darkColorScheme(background = Color(0xFF080A0F), surface = Color(0xFF11151D), primary = Color(0xFF35E7FF))) {
        Column(Modifier.fillMaxSize().background(Color(0xFF080A0F)).padding(18.dp)) {
            Text("SADEE", color = Color(0xFF35E7FF), fontSize = 30.sp, fontWeight = FontWeight.ExtraBold)
            Text("ANDROID OPTIMIZER", color = Color.White, fontSize = 13.sp, letterSpacing = 2.sp)
            Spacer(Modifier.height(18.dp))
            Card(shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFF111923)), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(20.dp)) {
                    Text(if (optimized) "OPTIMIZED" else "READY", color = if (optimized) Color(0xFF62FF9A) else Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    Text("Safe Android-level optimization controls", color = Color(0xFFAAB4C3), fontSize = 13.sp)
                    Spacer(Modifier.height(14.dp))
                    Button(onClick = { optimized = true }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
                        Text("⚡ QUICK OPTIMIZE", fontWeight = FontWeight.Bold)
                    }
                }
            }
            Spacer(Modifier.height(16.dp))
            val cards = listOf("RAM" to "$usedRam%", "BATTERY" to "$battery%", "STORAGE" to "Ready", "GAMING MODE" to "Ready")
            LazyVerticalGrid(columns = GridCells.Fixed(2), horizontalArrangement = Arrangement.spacedBy(12.dp), verticalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.weight(1f)) {
                items(cards) { (title, value) ->
                    Card(shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFF11151D))) {
                        Column(Modifier.padding(16.dp).fillMaxWidth()) {
                            Text(title, color = Color(0xFF7F8B9C), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(8.dp))
                            Text(value, color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
            Text("V1 • Android 8+ • Lightweight", color = Color(0xFF566170), fontSize = 11.sp, modifier = Modifier.align(Alignment.CenterHorizontally))
        }
    }
}
